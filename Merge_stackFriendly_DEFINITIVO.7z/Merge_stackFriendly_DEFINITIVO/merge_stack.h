#ifndef MERGE_STACK_H_INCLUDED
#define MERGE_STACK_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define TAM 10000

void le_vetor(double vet[]);
void separa_vetor(double vet[], int inicio, int fim);
void junta_vetor(double vet[], int inicio, int fim);

#endif // MERGE_STACK_H_INCLUDED
